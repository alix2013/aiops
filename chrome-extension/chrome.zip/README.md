# Install chrome extension

- Open the Chrome browser and navigate to chrome://extensions/.
- Enable Developer mode by clicking the toggle switch in the top right corner.
- Click the "Load unpacked" button and select the directory containing your unpacked extension, The extension will now be installed 
- Pin the extension on menu: click the puzzle piece on the top right of your browser. This will open a drop-down of all your Chrome Extensions. From here, simply click the little pin next to the Chrome Extensions
- config serverURL: right clicked pined icon, choose option, input serverURL
- Open chrome, access any page, select text then right click, choose sub-menu item


